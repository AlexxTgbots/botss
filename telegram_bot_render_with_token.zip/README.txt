ИНСТРУКЦИЯ ПО ЗАПУСКУ ЧЕРЕЗ RENDER:

1. Создай GitHub-репозиторий и загрузи туда эти 3 файла:
   - bot.py
   - requirements.txt
   - render.yaml

2. Перейди на https://render.com и нажми "New → Web Service"

3. Подключи GitHub, выбери этот репозиторий

4. Нажми "Create Web Service"

5. В bot.py замени YOUR_BOT_TOKEN на токен от @BotFather

Готово! Бот будет работать 24/7 на Render.
